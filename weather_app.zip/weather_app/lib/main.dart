import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_weather_icons/flutter_weather_icons.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'settings_page.dart';
import 'location.dart';
import 'dart:convert';

final Map days = {
  1: "Monday",
  2: "Tuesday",
  3: "Wednesday",
  4: "Thursday",
  5: "Friday",
  6: "Saturday",
  7: "Sunday"
};

final Map months = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December",
};

final DateTime date = DateTime.now();
const kLabelTextStyle = TextStyle(
  color: Colors.grey,
  fontSize: 13,
  fontWeight: FontWeight.w300,
);

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: <String, WidgetBuilder>{
        '/settings': (BuildContext context) => SettingsPage(),
      },
      theme: ThemeData.dark(),
      home: MyScaffold(),
    );
  }
}

class MyScaffold extends StatefulWidget {
  @override
  _MyScaffoldState createState() => _MyScaffoldState();
}

class _MyScaffoldState extends State<MyScaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          "${days[date.weekday]}, ${date.day} ${months[date.month]}, ${date.year}",
          style: kLabelTextStyle.copyWith(letterSpacing: 2),
        ),
        actions: <Widget>[
          FlatButton(
            shape: CircleBorder(),
            onPressed: () {
              Navigator.of(context).pushNamed('/settings');
            },
            child: Icon(
              Icons.more_vert,
              color: Colors.grey.shade700,
            ),
          ),
        ],
      ),
      body: AppBody(),
    );
  }
}

class AppBody extends StatefulWidget {
  @override
  _AppBodyState createState() => _AppBodyState();
}

class _AppBodyState extends State<AppBody> {
  TextEditingController controller;
  void getLocation() async {
    Location location = Location();
    await location.getCurrentLocation();
    print(location.latitude);
    print(location.longitude);
  }

  getName() async {
    http.Response response = await http.get(
        "https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=439d4b804bc8187953eb36d2a8c26a02");
    if (response.statusCode == 200) {
      String data = response.body;
      return jsonDecode(data)['name'];
    } else {
      print(response.statusCode);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLocation();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      padding: EdgeInsets.fromLTRB(15, 40, 15, 40),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            TextField(
              controller: controller,
              onSubmitted: (text) {
                Navigator.of(context).pushNamed('/settings');
              },
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                hintText: 'Enter your City name',
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                  borderRadius: BorderRadius.all(
                    Radius.circular(40),
                  ),
                ),
              ),
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 25,
                letterSpacing: 3,
              ),
            ),
            SizedBox(height: 15),
            Text(
              'SCATTERED CLOUDS',
              style: kLabelTextStyle.copyWith(
                letterSpacing: 3,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Icon(
              WeatherIcons.wiDayCloudy,
              size: 70,
            ),
            SizedBox(height: 10),
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    '30',
                    style:
                        TextStyle(fontSize: 100, fontWeight: FontWeight.w200),
                  ),
                  Text(
                    'o',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.w200),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Text(
                        'max',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(height: 10),
                      Text(
                        '31',
                      ),
                    ],
                  ),
                  VerticalDivider(
                    width: 40,
                    thickness: 1.0,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'min',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(height: 10),
                      Text(
                        '29',
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Divider(
              thickness: 1.0,
              height: 1,
            ),
            SizedBox(height: 20),
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Text(
                        'Thu, 5PM',
                        style: kLabelTextStyle,
                      ),
                      Icon(WeatherIcons.wiDayRainMix),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        '27',
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Thu, 8PM',
                        style: kLabelTextStyle,
                      ),
                      Icon(WeatherIcons.wiNightRain),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        '27',
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Thu, 11PM',
                        style: kLabelTextStyle,
                      ),
                      Icon(WeatherIcons.wiNightClear),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        '27',
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Fri, 2AM',
                        style: kLabelTextStyle,
                      ),
                      Icon(WeatherIcons.wiNightClear),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        '27',
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Fri, 5AM',
                        style: kLabelTextStyle,
                      ),
                      Icon(WeatherIcons.wiNightClear),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        '27',
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Divider(
              thickness: 1.0,
              height: 1,
            ),
            SizedBox(height: 20),
            IntrinsicHeight(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Text(
                        'wind speed',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text('5.1 m/s'),
                    ],
                  ),
                  VerticalDivider(
                    thickness: 1.0,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'sunrise',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text('5:54 AM'),
                    ],
                  ),
                  VerticalDivider(
                    thickness: 1.0,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'sunset',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text('6:47 PM'),
                    ],
                  ),
                  VerticalDivider(
                    thickness: 1.0,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'humidity',
                        style: kLabelTextStyle,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text('52%'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
