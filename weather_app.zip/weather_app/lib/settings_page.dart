import 'package:flutter/material.dart';
import 'package:flutter_weather_icons/flutter_weather_icons.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          children: <Widget>[
            ListTile(
              title: Text("Empty"),
              leading: Icon(WeatherIcons.wiMoonAltWaningCrescent4),
            ),
          ],
        ),
      ),
    );
  }
}
